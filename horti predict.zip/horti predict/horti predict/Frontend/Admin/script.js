// Script.js
document.querySelectorAll(".btn").forEach(button => {
    button.addEventListener("click", () => {
        alert("Aksi berhasil!");
    });
});
